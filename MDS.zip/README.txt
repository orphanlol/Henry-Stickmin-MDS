

Video instructions: https://www.youtube.com/watch?v=JCqjt8t43_M&feature=youtu.be

Hello! this mod is pretty easy to install.
First, go to Local Disk, Program files (x86)
Steam, Steamapps, common, HenryStickmin.
Once in this folder, make backups of these text documents.
"btb_english"
"etp_english"
"std_english"
"ita_english"
"ftc_english
"ctm_english"
remove all of them from the folder after making a backup.
then, once you have done that, drag the files included in this archive into the games folder.
then you are complete! once you start the game you will have more descriptive subtitles!
If it doesn't work, DM me on Game Banana, I'll try to help you.


Uninstall intructions:

Method 1: drag the backups of the oringinal subtitle files into the game folder and replace.

Method 2:Run steam and go to library, home, and right click on the Henry Stickmin Collection. Go to properties, local files, and verify integrity of game files.
